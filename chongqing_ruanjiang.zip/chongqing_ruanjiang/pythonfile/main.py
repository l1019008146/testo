from testdict import app1
app1().runapp1()

